# Yorkland Events Website

A modern, responsive party rental website for **Yorkland Events**. Built with pure HTML and CSS.

![Party Rental](https://via.placeholder.com/800x400?text=Yorkland+Events+Preview)

## Features
- **Marquee Letters**: Showcase for proposals and gender reveals.
- **Chairs & Tables**: Luxury seating options.
- **Moon Bounces**: Modern bounce house rentals.
- **Contact Form**: Visual contact section.
- **Responsive Design**: Looks great on mobile and desktop.
- **No JavaScript**: Fast and lightweight.

## Deployment
To deploy this site:
1. Upload these files to a web host (Netlify, Vercel, or GitHub Pages).
2. Ensure `index.html` is the entry point.

## Customization
Edit `style.css` to change colors or fonts. Current palette uses Hot Pink, Cyan, and Sunshine Yellow.

---
© 2024 Yorkland Events
